# Spring Boot JobRunr examples

https://mkyong.com/spring-boot/spring-boot-jobrunr-examples/

## How to run this?
```bash
$ git clone https://github.com/mkyong/spring-boot.git

$ cd spring-boot-jobrunr

$ mvn spring-boot:run
```
# Spring Boot + Spring data JPA

Article link : https://www.mkyong.com/spring-boot/spring-boot-spring-data-jpa/
# Spring Boot Hello World Example – Thymeleaf

Article link : https://www.mkyong.com/spring-boot/spring-boot-hello-world-example-thymeleaf/

## 1. How to start
```
$ git clone [https://github.com/mkyong/spring-boot.git](https://github.com/mkyong/spring-boot.git)
$ cd web-thymeleaf
$ mvn spring-boot:run

```

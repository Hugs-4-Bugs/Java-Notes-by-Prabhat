# Spring Boot + Spring data JPA + PostgreSQL example

Article link : https://www.mkyong.com/spring-boot/spring-boot/spring-boot-spring-data-jpa-postgresql/
